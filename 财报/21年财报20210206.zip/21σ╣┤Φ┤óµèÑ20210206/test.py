import pandas as pd
import numpy as np


def pivot_table1(df, values=None, index=None, columns=None, aggfunc='mean', ctx=None, *args, **kwargs):
    df = df.pivot_table(index=index, columns=columns, values=values, aggfunc=aggfunc)
    print(df.columns)
    df = df.reset_index()
    # print(df)

    if isinstance(columns, list) and len(columns) > 1:
        # print(222222, df.columns)
        df.columns = df.columns.map('_'.join)

    return df.reset_index()


# a = pd.read_excel('/Users/mahongtao/work/11111.xlsx')
# a = a.loc[a['ac_rule_kind'] == 'team1']
# # print(a)
# b = pivot_table1(a, values='money', index=['ac_code', 'ac_name'], columns=['team_name'])
# print(b.columns, '\n', b)

a = 10010.1001
x = "${:,.2f}".format(a)
print(x)
